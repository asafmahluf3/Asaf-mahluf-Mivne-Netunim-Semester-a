﻿using SofSemesterYearB;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;

namespace SofSemesterYearB
{
    internal class Course : IComparable<Course>
    {
        private string code;
        private double grade;
        public Course(string code, double grade)
        {
            this.code = code;
            this.grade = grade;
        }

        public string GetCode()
        {
            return code;
        }
        public void SetCode(string code)
        {
            this.code = code;
        }
        public double GetGrade()
        {
            return grade;
        }
        public void SetGrade(double grade)
        {
            this.grade = grade;
        }
        public override string ToString()
        {

            return $"code: {code}  grade: {grade}";
        }


        public override bool Equals(object obj)
        {
            if (obj == null || GetType() != obj.GetType())
            {
                return false;
            }

            return this.code == ((Course)obj).code && this.grade == ((Course)obj).grade;
        }
        public int CompareTo(Course other)
        {
            if (other == null) return 1;
            return this.grade.CompareTo(other.grade);
        }

    }
}






