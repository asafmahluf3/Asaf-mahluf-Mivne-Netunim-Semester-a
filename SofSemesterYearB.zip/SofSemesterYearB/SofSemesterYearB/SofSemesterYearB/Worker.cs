﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SofSemesterYearB
{
    internal class Worker : IComparable<Worker>
    {

        private string name;
        private double salary;

        public Worker(string name, double salary)
        {
            this.name = name;
            this.salary = salary;
        }

        public string GetName()
        {
            return name;
        }
        public double GetSalary()
        {
            return salary;
        }

        public void SetName(string name)
        {
           this.name = name;
        }


        public void SetSalary(double salary)
        {
            this.salary = salary;
        }
        public override bool Equals(object obj)
        {
            if (obj == null || GetType() != obj.GetType())
            {
                return false;
            }

            return this.name == ((Worker)obj).name && this.salary == ((Worker)obj).salary;
        }
        public override string ToString()
        {

            return $"name: {name}  salary: {salary}";
        }
        public int CompareTo(Worker other)
        {
            if (other == null) return 1;
            return this.salary.CompareTo(other.salary);
        }
    }
}
