﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SofSemesterYearB
{
    class Student
    {
        private string name;
        private Node<Course> courseList;

        public Student(string name)
        {
            this.name = name;
        }

        public void SetCourseList(Node<Course> course)
        {
            this.courseList = course;
        }

        public Student(string name, Node<Course> course)
        {
            this.name = name;
            this.courseList = course;
        }

        public string GetName()
        {
            return name;
        }
        public Node<Course> GetCourse()
        {
            return courseList;
        }
        public double GetAverage()
        {
            Node<Course> current = courseList;
            double total = 0;
            int count = 0;
            while (current != null)
            {
                total += current.GetValue().GetGrade();
                count++;
                current = current.GetNext();
            }
            return count > 0 ? total / count : 0.0;
        }


        public override string ToString()
        {

            return $"name: {name} courses and grades: {courseList}    ";
        }
        public void SetName(string name)
        {
            this.name = name;
        }

        

    }
}