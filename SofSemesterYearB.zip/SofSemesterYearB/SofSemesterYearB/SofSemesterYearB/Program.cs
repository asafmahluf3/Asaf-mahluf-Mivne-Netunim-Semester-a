﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SofSemesterYearB
{
    internal class Program
    {
        static void Main(string[] args)
        {

            Course course1 = new Course("CSC101", 90);
            Course course2 = new Course("MATH201", 85);
            Course course3 = new Course("HIST301", 80);
            Course course17 = new Course("HINO6969", 83);

            /*Node<Course> nodeCourse17 = new Node<Course>(course17);*/
            /*  Console.WriteLine(nodeCourse17.GetHashCode());*/
            Node<Course> nodeCourse3 = new Node<Course>(course3);
            Node<Course> nodeCourse2 = new Node<Course>(course2, nodeCourse3);
            Node<Course> nodeCourse1 = new Node<Course>(course1, nodeCourse2);
            /*nodeCourse3.SetNext(nodeCourse17);*/


            Console.WriteLine(nodeCourse1);
            Node<Course> list = nodeCourse1;
            //-----------Seif 1--------אורך הרשימה-------//
            Console.WriteLine("-----------Seif 1--------length of list-------");
            Console.ReadKey();
            Console.WriteLine(ListLength<Course>(list));


            //-----------Seif 2--------הדפסת הרשימה-------//
            Console.WriteLine("-----------Seif 2---------print all list------");
            Console.ReadKey();
            PrintTheList<Course>(list);
            Console.WriteLine(list);


            //-----------Seif 3-------הוספת ערך לתחילת הרשימה--------//
            Console.WriteLine("-----------Seif 3-------add value on start--------");
            Course course4 = new Course("BioLo301", 56);
            Console.ReadKey();
            list = AddFirst<Course>(list, course4);
            Console.WriteLine(list);


            //-----------Seif 4---------הוספת ערך לסוף הרשימה------//
            Console.WriteLine("-----------Seif 4---------add value on end------");
            Course course5 = new Course("SQL1548", 77);
            Console.ReadKey();
            list = AddLast<Course>(list, course5);
            Console.WriteLine(list);

            //-----------Seif 5---------הוספת ערך לאמצע הרשימה------//
            Console.WriteLine("-----------Seif 5--------add value on middle-------");
            Course course6 = new Course("Sport474", 100);
            Console.ReadKey();
            AddAfter<Course>(list.GetNext().GetNext(), course6);
            Console.WriteLine(list);

            //-----------Seif 6-------מחיקת ערך בתחילת הרשימה--------//
            Console.WriteLine("-----------Seif 6---------delete value from start------");
            Console.ReadKey();
            list = DeleteFirst<Course>(list);
            Console.WriteLine(list);

            //-----------Seif 7---------מחיקת ערך בסוף הרשימה------//
            Console.WriteLine("-----------Seif 7--------delete value from end-------");
            Console.ReadKey();
            list = DeleteLast<Course>(list);
            Console.WriteLine(list);
            //-----------Seif 8---------מחיקת ערך באמצע הרשימה------//
            Console.WriteLine("-----------Seif 8---------delete value from middle------");
            Console.ReadKey();
            DeleteAfter<Course>(list.GetNext());
            Console.WriteLine(list);

            //-----------Seif 9---------החזרת ערך בתחילת הרשימה------//
            Console.WriteLine("-----------Seif 9----------return value from start-----");
            Console.ReadKey();
            Console.WriteLine(ReturnFirstVal<Course>(list));

            //-----------Seif 10--------החזרת ערך בסוף הרשימה-------//
            Console.WriteLine("-----------Seif 10--------return value from end-------");
            Console.ReadKey();
            Console.WriteLine(ReturnLastVal<Course>(list));


            //-----------Seif 11--------החזרת ערך לפי אינדקס -------//
            Console.WriteLine("-----------Seif 11--------return value by index-------");
            Console.ReadKey();
            Console.WriteLine(ReturnValByIndex<Course>(list, 1));
            //-----------Seif 12--------בודק ערך שנשלח קיים ברשימה-------//
            Console.WriteLine("-----------Seif 12--------check if exist-------");
            Console.ReadKey();
            Course course7 = new Course("GEOG5566", 35);
            Console.WriteLine(IfValueIsIn<Course>(list, course7));
            //-----------Seif 13---------בדיקה מעגלית------//
            Console.WriteLine("-----------Seif 13--------check if circle-------");
            Console.ReadKey();
            nodeCourse3.SetNext(list);
            Console.WriteLine(IfCircular<Course>(list));
            //-----------Seif 14-------ניפוי ערכים כפולים--------//
            Console.WriteLine("-----------Seif 14-------remove duplicate values--------");
            Console.ReadKey();
            Course course9 = new Course("CSC101", 90);
            Node<Course> nodeCourse9 = new Node<Course>(course9);
            nodeCourse3.SetNext(nodeCourse9);
            Console.WriteLine(list);
            Console.ReadKey();
            RemoveDuplicates<Course>(list);
            Console.WriteLine(list);
            //-----------Seif 15------שכפול רשימה---------//
            Console.WriteLine("-----------Seif 15-------return new same list--------");
            Console.ReadKey();
            Console.WriteLine(list);
            Node<Course> NewList = NewSameList<Course>(list);
            Console.WriteLine("the new list");
            Console.WriteLine(NewList);
            //-----------Seif 16---------הפיכת רשימה------//
            Console.WriteLine("-----------Seif 16--------reverse list-------");
            Console.ReadKey();
            list = ReverseTheList<Course>(list);
            Console.WriteLine(list);
            //-----------Seif 17-------מיון מקטן לגדול--------//
            Console.WriteLine("-----------Seif 17--------sort from S-B -------");
            Console.ReadKey();
            /*      Course course880 = new Course("TryEX17", 89);
                  list = AddFirst<Course>(list, course880);*/
            Console.WriteLine(list);
            Console.ReadKey();

            SortList<Course>(list);
            Console.WriteLine(list);
            //-----------Seif 18------בדיקה אם שתי רשימות עם אותו התוכן---------//
            Console.WriteLine("-----------Seif 18--------check both list have same values-------");
            Course course11 = new Course("CSC101", 90);
            Course course22 = new Course("MATH201", 85);
            Course course33 = new Course("HIST301", 80);
            Node<Course> nodeCourse33 = new Node<Course>(course33);
            Node<Course> nodeCourse22 = new Node<Course>(course22, nodeCourse33);
            Node<Course> nodeCourse11 = new Node<Course>(course11, nodeCourse22);
            Node<Course> list2 = nodeCourse11;
            Console.WriteLine("the lists: ");
            Console.WriteLine(list);
            Console.WriteLine(list2);
            Console.ReadKey();
            Console.WriteLine(IfTheListTheSame<Course>(list, list2));
            //-----------Seif 19--------מיזוג שתי רשימות-------//
            Console.WriteLine("-----------Seif 19--------merge two lists-------");
            Console.ReadKey();
            Node<Course> newList = Combine2Lists(list, list2);
            Console.WriteLine(list2);
            Console.WriteLine(list);
            Console.WriteLine(newList);
            //-----------Seif 20-------שילוב בלי כפילויות--------//
            Console.WriteLine("-----------Seif 20--------merge without clones-------");
            Console.ReadKey();
            Node<Course> newListSeif20 = Combine2ListsNoDup(list, list2);
            Console.WriteLine(newListSeif20);
            //-----------Seif 21------שילוב של שתי רשימות רק עם ערכים שנמצאים בשתי הרשימות---------//
            Console.WriteLine("-----------Seif 21--------merge only values that have in bothes lists-------");
            Console.ReadKey();
            /* Course course256 = new Course("kjasdkj", 880);
             list = AddFirst(list, course256);
             Console.WriteLine(list);
             Console.WriteLine(list2);
             Console.ReadKey();*/
            Node<Course> Combine2L = Combine2ListSameVal(list, list2);
            Console.WriteLine(Combine2L);



            //---------------------------------Seif 22----------------------------------//
            Console.WriteLine("-----------Seif 22---------again till seif 21 but with ints------");
            Console.ReadKey();

            //-----------Nodes of int---------------//
            Node<int> nodeInt4 = new Node<int>(1);
            Node<int> nodeInt3 = new Node<int>(2, nodeInt4);
            Node<int> nodeInt2 = new Node<int>(7, nodeInt3);
            Node<int> nodeInt1 = new Node<int>(5, nodeInt2);


            Node<int> listOfInt = nodeInt1;
            Console.WriteLine(listOfInt);

            //-----------Function 1---------------//
            Console.WriteLine("-----------Function 1---------------");
            Console.ReadKey();
            Console.WriteLine(ListLength<int>(listOfInt));
            Console.WriteLine("-----------Seif 1---------------");
            Console.ReadKey();
            Console.WriteLine(ListLength<int>(listOfInt));


            //-----------Seif 2---------------//
            Console.WriteLine("-----------Seif 2---------------");
            Console.ReadKey();
            PrintTheList<int>(listOfInt);
            Console.WriteLine(listOfInt);


            //-----------Seif 3---------------//
            Console.WriteLine("-----------Seif 3---------------");
            int int4 = 56;
            Console.ReadKey();
            listOfInt = AddFirst<int>(listOfInt, int4);
            Console.WriteLine(listOfInt);


            //-----------Seif 4---------------//
            Console.WriteLine("-----------Seif 4---------------");
            int int5 = 77;
            Console.ReadKey();
            listOfInt = AddLast<int>(listOfInt, int5);
            Console.WriteLine(listOfInt);

            //-----------Seif 5---------------//
            Console.WriteLine("-----------Seif 5---------------");
            int int6 = 100;
            Console.ReadKey();
            AddAfter<int>(listOfInt.GetNext().GetNext(), int6);
            Console.WriteLine(listOfInt);

            //-----------Seif 6---------------//
            Console.WriteLine("-----------Seif 6---------------");
            Console.ReadKey();
            listOfInt = DeleteFirst<int>(listOfInt);
            Console.WriteLine(listOfInt);

            //-----------Seif 7---------------//
            Console.WriteLine("-----------Seif 7---------------");
            Console.ReadKey();
            listOfInt = DeleteLast<int>(listOfInt);
            Console.WriteLine(listOfInt);
            //-----------Seif 8---------------//
            Console.WriteLine("-----------Seif 8---------------");
            Console.ReadKey();
            DeleteAfter<int>(listOfInt.GetNext());
            Console.WriteLine(listOfInt);

            //-----------Seif 9---------------//
            Console.WriteLine("-----------Seif 9---------------");
            Console.ReadKey();
            Console.WriteLine(ReturnFirstVal<int>(listOfInt));

            //-----------Seif 10---------------//
            Console.WriteLine("-----------Seif 10---------------");
            Console.ReadKey();
            Console.WriteLine(ReturnLastVal<int>(listOfInt));


            //-----------Seif 11---------------//
            Console.WriteLine("-----------Seif 11---------------");
            Console.ReadKey();
            Console.WriteLine(ReturnValByIndex<int>(listOfInt, 1));
            //-----------Seif 12---------------//
            Console.WriteLine("-----------Seif 12---------------");
            Console.ReadKey();
            int int7 = 35;
            Console.WriteLine(IfValueIsIn<int>(listOfInt, int7));
            //-----------Seif 13---------------//
            Console.WriteLine("-----------Seif 13---------------");
            Console.ReadKey();
            nodeInt3.SetNext(listOfInt);
            Console.WriteLine(IfCircular<int>(listOfInt));
            //-----------Seif 14---------------//
            Console.WriteLine("-----------Seif 14---------------");
            Console.ReadKey();
            int int9 = 90;
            Node<int> nodeInt9 = new Node<int>(int9);
            nodeInt3.SetNext(nodeInt9);
            Console.WriteLine(listOfInt);
            Console.ReadKey();
            RemoveDuplicates<int>(listOfInt);
            Console.WriteLine(listOfInt);
            Console.WriteLine("-----------Seif 15---------------");
            Console.ReadKey();
            Console.WriteLine(listOfInt);
            Node<int> NewIntList = NewSameList<int>(listOfInt);
            Console.WriteLine("the new list");
            Console.WriteLine(NewIntList);
            //-----------Seif 16---------------//
            Console.WriteLine("-----------Seif 16---------------");
            Console.ReadKey();
            listOfInt = ReverseTheList<int>(listOfInt);
            Console.WriteLine(listOfInt);
            //-----------Seif 17---------------//
            Console.WriteLine("-----------Seif 17---------------");
            Console.ReadKey();
            /*      Course course880 = new Course("TryEX17", 89);
                  list = AddFirst<Course>(list, course880);*/
            Console.WriteLine(listOfInt);
            Console.ReadKey();

            SortList<int>(listOfInt);
            Console.WriteLine(listOfInt);
            //-----------Seif 18---------------//
            Console.WriteLine("-----------Seif 18---------------");

            int int11 = 90;
            int int22 = 85;
            int int33 = 80;
            Node<int> intNode33 = new Node<int>(int33);
            Node<int> intNode22 = new Node<int>(int22, intNode33);
            Node<int> intNode11 = new Node<int>(int11, intNode22);
            Node<int> listNodes2 = intNode11;
            Console.WriteLine("the lists: ");
            Console.WriteLine(listOfInt);
            Console.WriteLine(listNodes2);
            Console.ReadKey();
            Console.WriteLine(IfTheListTheSame<int>(listOfInt, listNodes2));
            //-----------Seif 19---------------//
            Console.WriteLine("-----------Seif 19---------------");
            Console.ReadKey();
            Node<int> newListOfInt = Combine2Lists(listOfInt, listNodes2);
            Console.WriteLine(listNodes2);
            Console.WriteLine(listOfInt);
            Console.WriteLine(newListOfInt);
            //-----------Seif 20---------------//
            Console.WriteLine("-----------Seif 20---------------");
            Console.ReadKey();
            Node<int> newListIntsSeif20 = Combine2ListsNoDup(listOfInt, listNodes2);
            Console.WriteLine(newListIntsSeif20);
            //-----------Seif 21---------------//
            Console.WriteLine("-----------Seif 21---------------");
            Console.ReadKey();
            /* Course course256 = new Course("kjasdkj", 880);
             list = AddFirst(list, course256);
             Console.WriteLine(list);
             Console.WriteLine(list2);
             Console.ReadKey();*/
            Node<int> Combine2ListsOfint = Combine2ListSameVal(listOfInt, listNodes2);
            Console.WriteLine(Combine2ListsOfint);




            Console.WriteLine("-----------Seif 22 Workers---------------");
            Worker Worker1 = new Worker("Nadav", 35.2);
            Worker Worker2 = new Worker("yonatan", 85.50);
            Worker Worker3 = new Worker("rami", 8);

            Node<Worker> nodeWorker3 = new Node<Worker>(Worker3);
            Node<Worker> nodeWorker2 = new Node<Worker>(Worker2, nodeWorker3);
            Node<Worker> nodeWorker1 = new Node<Worker>(Worker1, nodeWorker2);
            Node<Worker> listOfWorker = nodeWorker1;
            //-----------Seif 1---------------//
            Console.WriteLine("-----------Seif 1---------again till seif 21 but with workers------");
            Console.ReadKey();
            Console.WriteLine(ListLength<Worker>(listOfWorker));


            //-----------Seif 2---------------//
            Console.WriteLine("-----------Seif 2---------------");
            Console.ReadKey();
            PrintTheList<Worker>(listOfWorker);
            Console.WriteLine(listOfWorker);


            //-----------Seif 3---------------//
            Console.WriteLine("-----------Seif 3---------------");
            Worker Worker4 = new Worker("avinimni", 56);
            Console.ReadKey();
            listOfWorker = AddFirst<Worker>(listOfWorker, Worker4);
            Console.WriteLine(listOfWorker);


            //-----------Seif 4---------------//
            Console.WriteLine("-----------Seif 4---------------");
            Worker Worker5 = new Worker("tami", 77);
            Console.ReadKey();
            listOfWorker = AddLast<Worker>(listOfWorker, Worker5);
            Console.WriteLine(listOfWorker);

            //-----------Seif 5---------------//
            Console.WriteLine("-----------Seif 5---------------");
            Worker Worker6 = new Worker("menii", 100);
            Console.ReadKey();
            AddAfter<Worker>(listOfWorker.GetNext().GetNext(), Worker6);
            Console.WriteLine(listOfWorker);

            //-----------Seif 6---------------//
            Console.WriteLine("-----------Seif 6---------------");
            Console.ReadKey();
            listOfWorker = DeleteFirst<Worker>(listOfWorker);
            Console.WriteLine(listOfWorker);

            //-----------Seif 7---------------//
            Console.WriteLine("-----------Seif 7---------------");
            Console.ReadKey();
            listOfWorker = DeleteLast<Worker>(listOfWorker);
            Console.WriteLine(listOfWorker);
            //-----------Seif 8---------------//
            Console.WriteLine("-----------Seif 8---------------");
            Console.ReadKey();
            DeleteAfter<Worker>(listOfWorker.GetNext());
            Console.WriteLine(listOfWorker);

            //-----------Seif 9---------------//
            Console.WriteLine("-----------Seif 9---------------");
            Console.ReadKey();
            Console.WriteLine(ReturnFirstVal<Worker>(listOfWorker));

            //-----------Seif 10---------------//
            Console.WriteLine("-----------Seif 10---------------");
            Console.ReadKey();
            Console.WriteLine(ReturnLastVal<Worker>(listOfWorker));


            //-----------Seif 11---------------//
            Console.WriteLine("-----------Seif 11---------------");
            Console.ReadKey();
            Console.WriteLine(ReturnValByIndex<Worker>(listOfWorker, 1));
            //-----------Seif 12---------------//
            Console.WriteLine("-----------Seif 12---------------");
            Console.ReadKey();
            Worker Worker7 = new Worker("jovani", 35);
            Console.WriteLine(IfValueIsIn<Worker>(listOfWorker, Worker7));
            //-----------Seif 13---------------//
            Console.WriteLine("-----------Seif 13---------------");
            Console.ReadKey();
            nodeWorker3.SetNext(listOfWorker);
            Console.WriteLine(IfCircular<Worker>(listOfWorker));
            //-----------Seif 14---------------//
            Console.WriteLine("-----------Seif 14---------------");
            Console.ReadKey();
            Worker Worker9 = new Worker("sidvanit", 90);
            Node<Worker> nodeWorker9 = new Node<Worker>(Worker9);
            nodeWorker3.SetNext(nodeWorker9);
            Console.WriteLine(listOfWorker);
            Console.ReadKey();
            RemoveDuplicates<Worker>(listOfWorker);
            Console.WriteLine(listOfWorker);
            //-----------Seif 15---------------//
            Console.WriteLine("-----------Seif 15---------------");
            Console.ReadKey();
            Console.WriteLine(listOfWorker);
            Node<Worker> NewListofworkers = NewSameList<Worker>(listOfWorker);
            Console.WriteLine("the new list");
            Console.WriteLine(listOfWorker);
            //-----------Seif 16---------------//
            Console.WriteLine("-----------Seif 16---------------");
            Console.ReadKey();
            listOfWorker = ReverseTheList<Worker>(listOfWorker);
            Console.WriteLine(listOfWorker);
            //-----------Seif 17---------------//
            Console.WriteLine("-----------Seif 17---------------");
            Console.ReadKey();
            /*      Course course880 = new Course("TryEX17", 89);
                  list = AddFirst<Course>(list, course880);*/
            Console.WriteLine(listOfWorker);
            Console.ReadKey();

            SortList<Worker>(listOfWorker);
            Console.WriteLine(listOfWorker);
            //-----------Seif 18---------------//
            Console.WriteLine("-----------Seif 18---------------");
            Worker worker11 = new Worker("zion", 90);
            Worker worker22 = new Worker("tal", 85);
            Worker worker33 = new Worker("nir", 80);
            Node<Worker> nodeWorker33 = new Node<Worker>(worker33);
            Node<Worker> nodeWorker22 = new Node<Worker>(worker22, nodeWorker33);
            Node<Worker> nodeWorker11 = new Node<Worker>(worker11, nodeWorker22);
            Node<Worker> listOfWorker2 = nodeWorker11;
            Console.WriteLine("the lists: ");
            Console.WriteLine(listOfWorker2);
            Console.WriteLine(listOfWorker);
            Console.ReadKey();
            Console.WriteLine(IfTheListTheSame<Worker>(listOfWorker, listOfWorker2));
            //-----------Seif 19---------------//
            Console.WriteLine("-----------Seif 19---------------");
            Console.ReadKey();
            Node<Worker> newWorkerList = Combine2Lists(listOfWorker, listOfWorker2);
            Console.WriteLine(listOfWorker2);
            Console.WriteLine(listOfWorker);
            Console.WriteLine(newWorkerList);
            //-----------Seif 20---------------//
            Console.WriteLine("-----------Seif 20---------------");
            Console.ReadKey();
            Node<Worker> newListWorkerSeif20 = Combine2ListsNoDup(listOfWorker, listOfWorker2);
            Console.WriteLine(newListWorkerSeif20);
            //-----------Seif 21---------------//
            Console.WriteLine("-----------Seif 21---------------");
            Console.ReadKey();
            /* Course course256 = new Course("kjasdkj", 880);
             list = AddFirst(list, course256);
             Console.WriteLine(list);
             Console.WriteLine(list2);
             Console.ReadKey();*/
            Console.WriteLine(listOfWorker);
            Console.WriteLine(listOfWorker2);
            Node<Worker> Combine2WorkerList = Combine2ListSameVal(listOfWorker, listOfWorker2);
            Console.WriteLine(Combine2WorkerList);



            Console.WriteLine("-----------Seif 23-------print every avg of student in list--------");
            //-----------------------Seif 23-------------------הדפסה ממוצע כל סטודנט ברשימה-----------//
            //----------Student 1----------//
            Course course1stud1 = new Course("CSC101", 90);
            Course course2stud1 = new Course("MATH201", 85);
            Course course3stud1 = new Course("HIST301", 80);
            Node<Course> nodeCourse3stud1 = new Node<Course>(course3stud1);
            Node<Course> nodeCourse2stud1 = new Node<Course>(course2stud1, nodeCourse3stud1);
            Node<Course> nodeCourse1stud1 = new Node<Course>(course1stud1, nodeCourse2stud1);
            Node<Course> listOfCoursesStud1 = nodeCourse1stud1;

            //----------Student 2----------//
            Course course1stud2 = new Course("CSC101", 98);
            Course course2stud2 = new Course("MATH201", 86);
            Course course3stud2 = new Course("HIST301", 76);
            Node<Course> nodeCourse3stud2 = new Node<Course>(course3stud2);
            Node<Course> nodeCourse2stud2 = new Node<Course>(course2stud2, nodeCourse3stud2);
            Node<Course> nodeCourse1stud2 = new Node<Course>(course1stud2, nodeCourse2stud2);
            Node<Course> listOfCoursesStud2 = nodeCourse1stud2;

            //----------Student 3----------//
            Course course1stud3 = new Course("CSC101", 70);
            Course course2stud3 = new Course("MATH201", 54);
            Course course3stud3 = new Course("HIST301", 16);
            Node<Course> nodeCourse3stud3 = new Node<Course>(course3stud3);
            Node<Course> nodeCourse2stud3 = new Node<Course>(course2stud3, nodeCourse3stud3);
            Node<Course> nodeCourse1stud3 = new Node<Course>(course1stud3, nodeCourse2stud3);
            Node<Course> listOfCoursesStud3 = nodeCourse1stud3;




            Student student1 = new Student("yair", listOfCoursesStud1);
            Student student2 = new Student("asaf", listOfCoursesStud2);
            Student student3 = new Student("elad", listOfCoursesStud3);


            Node<Student> nodeStudent3 = new Node<Student>(student3);
            Node<Student> nodeStudent2 = new Node<Student>(student2, nodeStudent3);
            Node<Student> nodeStudent1 = new Node<Student>(student1, nodeStudent2);
            Node<Student> allStudents = nodeStudent1;
            Console.ReadKey();
            Console.WriteLine(allStudents);
            AverageStudens(allStudents);


            Console.WriteLine("-----------Seif 24--------return new list with exellent students in every class-------");
            Console.ReadKey();
            //-----------------------Seif 24--------------החזרת רשימה חדשה עם כל התלמידים המצטיינים מכל כיתה----------------//

            Course course1stud11 = new Course("CSC101", 45);
            Course course2stud11 = new Course("MATH201", 75);
            Course course3stud11 = new Course("HIST301", 20);
            Node<Course> nodeCourse3stud11 = new Node<Course>(course3stud11);
            Node<Course> nodeCourse2stud11 = new Node<Course>(course2stud11, nodeCourse3stud11);
            Node<Course> nodeCourse1stud11 = new Node<Course>(course1stud11, nodeCourse2stud11);
            Node<Course> listOfCoursesStud11 = nodeCourse1stud11;

            //----------Student 2----------//
            Course course1stud22 = new Course("CSC101", 48);
            Course course2stud22 = new Course("MATH201", 89);
            Course course3stud22 = new Course("HIST301", 72);
            Node<Course> nodeCourse3stud22 = new Node<Course>(course3stud22);
            Node<Course> nodeCourse2stud22 = new Node<Course>(course2stud22, nodeCourse3stud22);
            Node<Course> nodeCourse1stud22 = new Node<Course>(course1stud22, nodeCourse2stud22);
            Node<Course> listOfCoursesStud22 = nodeCourse1stud22;

            //----------Student 3----------//
            Course course1stud33 = new Course("CSC101", 73);
            Course course2stud33 = new Course("MATH201", 58);
            Course course3stud33 = new Course("HIST301", 15);
            Node<Course> nodeCourse3stud33 = new Node<Course>(course3stud33);
            Node<Course> nodeCourse2stud33 = new Node<Course>(course2stud33, nodeCourse3stud33);
            Node<Course> nodeCourse1stud33 = new Node<Course>(course1stud33, nodeCourse2stud33);
            Node<Course> listOfCoursesStud33 = nodeCourse1stud33;




            Student student11 = new Student("ofek", listOfCoursesStud11);
            Student student22 = new Student("alon", listOfCoursesStud22);
            Student student33 = new Student("shaked", listOfCoursesStud33);

            Course course1stud111 = new Course("CSC101", 99);
            Course course2stud111 = new Course("MATH201", 88);
            Course course3stud111 = new Course("HIST301", 88);
            Node<Course> nodeCourse3stud111 = new Node<Course>(course3stud111);
            Node<Course> nodeCourse2stud111 = new Node<Course>(course2stud111, nodeCourse3stud111);
            Node<Course> nodeCourse1stud111 = new Node<Course>(course1stud111, nodeCourse2stud111);
            Node<Course> listOfCoursesStud111 = nodeCourse1stud111;

            //----------Student 2----------//
            Course course1stud222 = new Course("CSC101", 9);
            Course course2stud222 = new Course("MATH201", 8);
            Course course3stud222 = new Course("HIST301", 7);
            Node<Course> nodeCourse3stud222 = new Node<Course>(course3stud222);
            Node<Course> nodeCourse2stud222 = new Node<Course>(course2stud222, nodeCourse3stud222);
            Node<Course> nodeCourse1stud222 = new Node<Course>(course1stud222, nodeCourse2stud222);
            Node<Course> listOfCoursesStud222 = nodeCourse1stud222;

            //----------Student 3----------//
            Course course1stud333 = new Course("CSC101", 44);
            Course course2stud333 = new Course("MATH201", 57);
            Course course3stud333 = new Course("HIST301", 11);
            Node<Course> nodeCourse3stud333 = new Node<Course>(course3stud333);
            Node<Course> nodeCourse2stud333 = new Node<Course>(course2stud333, nodeCourse3stud333);
            Node<Course> nodeCourse1stud333 = new Node<Course>(course1stud333, nodeCourse2stud333);
            Node<Course> listOfCoursesStud333 = nodeCourse1stud333;




            Student student111 = new Student("daniel", listOfCoursesStud111);
            Student student222 = new Student("koren", listOfCoursesStud222);
            Student student333 = new Student("yoav", listOfCoursesStud333);

            //------------------------------------------------------------//
            Student[] class1 = { student1, student2, student3 };
            Student[] class2 = { student11, student22, student33 };
            Student[] class3 = { student111, student222, student333 };
            Node<Student[]> nodeClass3 = new Node<Student[]>(class3);
            Node<Student[]> nodeClass2 = new Node<Student[]>(class2, nodeClass3);
            Node<Student[]> nodeClass1 = new Node<Student[]>(class1, nodeClass2);
            Node<Student[]> listOfNodesClasses = nodeClass1;


            Console.WriteLine(WhoIsGoodStudent(listOfNodesClasses));

            Console.WriteLine("-----------Seif 25------array with every student from every class with the most failures---------");
            Console.ReadKey();

            Node<Student>[] classes = new Node<Student>[3];


            Node<Student> stud3class1 = new Node<Student>(student3);
            Node<Student> stud2class1 = new Node<Student>(student2, stud3class1);
            Node<Student> stud1class1 = new Node<Student>(student1, stud2class1);
            classes[0] = stud1class1;

            Node<Student> stud3class2 = new Node<Student>(student33);
            Node<Student> stud2class2 = new Node<Student>(student22, stud3class2);
            Node<Student> stud1class2 = new Node<Student>(student11, stud2class2);
            classes[1] = stud1class2;

            Node<Student> stud3class3 = new Node<Student>(student333);
            Node<Student> stud2class3 = new Node<Student>(student222, stud3class3);
            Node<Student> stud1class3 = new Node<Student>(student111, stud2class3);
            classes[2] = stud1class3;

            Student[] returnArrey = WhoIsBadStudent(classes);

            for (int i = 0; i < returnArrey.Length; i++)
            {
                Console.WriteLine(returnArrey[i]);
            }


        }

        //-----------------------Seif 25--------------------------------//
        public static Student[] WhoIsBadStudent(Node<Student>[] classes)
        {
            int tempMostFailre = 0;
            Student MostFailureStud = null;
            Student[] arrayOfFailures = new Student[classes.Length];

            for (int i = 0; i < classes.Length; i++)
            {
                Node<Student> tempstudentList = classes[i];
                while (tempstudentList != null)
                {
                    int currentFailure = 0;
                    Node<Course> tempstudentCourse = tempstudentList.GetValue().GetCourse();
                    while (tempstudentCourse!= null)
                    {
                        if (tempstudentCourse.GetValue().GetGrade() < 55)
                        {
                            currentFailure++;
                        }
                        tempstudentCourse = tempstudentCourse.GetNext();
                    }
                    if(currentFailure > tempMostFailre)
                    {
                        tempMostFailre = currentFailure;
                        MostFailureStud = tempstudentList.GetValue();
                    }
                    tempstudentList = tempstudentList.GetNext();
                }

                arrayOfFailures[i] = MostFailureStud;
                tempMostFailre = 0;
            }
            return arrayOfFailures;


        }

        //-----------------------Seif 24--------------------------------//
        public static Node<Student> WhoIsGoodStudent(Node<Student[]> listOfNodesClasses)
        {
            double tempMaxAvg = 0;
            Student maxStud = null;
            Node<Student> listOfExell = null;
            Node<Student> tempListOfExell = listOfExell;


            //              מחזיק רשימה של כיתות
            Node<Student[]> tempList = listOfNodesClasses;

            while (tempList != null)
            {
               


                //        מחזיק מערך של סטודנטים
                Student[] tempClass = tempList.GetValue();

                

                for (int i = 0; i < tempClass.Length; i++)
                {
                    Student tempStudent = tempClass[i];
                    if (tempStudent.GetAverage() > tempMaxAvg)
                    {
                        tempMaxAvg = tempStudent.GetAverage();
                        maxStud = tempStudent;
                    }
                }
                if (listOfExell == null)
                {
                    listOfExell = new Node<Student>(maxStud);
                    tempListOfExell = listOfExell;
                }
                else
                {
                    tempListOfExell.SetNext(new Node<Student>(maxStud));
                    tempListOfExell = tempListOfExell.GetNext();
                }
                tempMaxAvg = 0;
                tempList = tempList.GetNext();
            }
            return listOfExell;
        }



        //-----------------------Seif 23------------------------------//
        public static void AverageStudens(Node<Student> allStudents)
        {
            int counter = 0;
            Node<Student> tempStudent = allStudents;
            Node<Course> tempCourse = tempStudent.GetValue().GetCourse();
            double averageOfStudent = 0;

            while (tempStudent != null)
            {
                while (tempCourse != null)
                {
                    counter++;
                    averageOfStudent += tempCourse.GetValue().GetGrade();
                    tempCourse = tempCourse.GetNext();
                }
                Console.WriteLine(averageOfStudent / counter);
                tempStudent = tempStudent.GetNext();
                if (tempStudent == null)
                {
                    break;
                }
                tempCourse = tempStudent.GetValue().GetCourse();
                counter = 0;
                averageOfStudent = 0;
            }
        }






        //-----------------------Seif 21------------------------------//
        public static Node<T> Combine2ListSameVal<T>(Node<T> list1, Node<T> list2)
        {
            RemoveDuplicates(list1);
            RemoveDuplicates(list2);

            Node<T> NewList = null;
            Node<T> temp1 = list1;
            Node<T> temp2 = list2;
            while (temp1 != null)
            {
                while (temp2 != null)
                {
                    if (temp1.GetValue().Equals(temp2.GetValue()))
                    {
                        NewList = AddFirst(NewList, temp1.GetValue());
                    }
                    temp2 = temp2.GetNext();
                }
                temp2 = list2;
                temp1 = temp1.GetNext();
            }
            return NewList;



        }
        //-----------------------Seif 20------------------------------//
        public static Node<T> Combine2ListsNoDup<T>(Node<T> list1, Node<T> list2)
        {
            Node<T> NewList = Combine2Lists(list1, list2);
            RemoveDuplicates(NewList);
            return NewList;


        }
        //-----------------------Seif 19------------------------------//
        public static Node<T> Combine2Lists<T>(Node<T> list1, Node<T> list2)
        {
            Node<T> NewList = NewSameList<T>(list1);
            Node<T> current = NewList;

            while (current.HasNext())
            {
                current = current.GetNext();
            }
            current.SetNext(list2);
            return NewList;
        }
        //-----------------------Seif 18------------------------------//
        public static bool IfTheListTheSame<T>(Node<T> list1, Node<T> list2) where T : IComparable<T>
        {
            SortList(list1);
            SortList(list2);
            Node<T> current1 = list1;
            Node<T> current2 = list2;
            while (current1 != null && current2 != null)
            {
                if (!current1.GetValue().Equals(current2.GetValue()))
                {
                    return false;
                }
                current1 = current1.GetNext();
                current2 = current2.GetNext();
            }
            return current1 == null && current2 == null;
        }
        //-----------------------Seif 17------------------------------//
        public static void SortList<T>(Node<T> head) where T : IComparable<T>
        {

            Node<T> current = head;//המשתנה שעובר על כל הרשימה
            //הלואה שעוברת על כל הרשימה
            while (current != null)
            {
                // הלולאה השנייה שעוברת על הרשימה מהנוד הבא
                Node<T> next = current.GetNext();
                while (next != null)
                {
                    // אם הערך של הצמוד הנוכחי גדול מהבא, החלפת הערכים באמצעות משתנה זמני
                    if (current.GetValue().CompareTo(next.GetValue()) > 0)
                    {
                        T temp = current.GetValue();
                        current.SetValue(next.GetValue());
                        next.SetValue(temp);
                    }
                    next = next.GetNext();
                }
                current = current.GetNext();
            }
        }



        //-----------------------Seif 16------------------------------//
        public static Node<T> ReverseTheList<T>(Node<T> head)
        {
            Node<T> current = head;
            Node<T> prev = null;
            Node<T> next = null;
            while (current != null)
            {
                next = current.GetNext();
                current.SetNext(prev);
                prev = current;
                //pre = 10
                current = next;
            }
            return prev;
        }
        //-----------------------Seif 15------------------------------//
        public static Node<T> NewSameList<T>(Node<T> list)
        {
            Node<T> NewList = new Node<T>(list.GetValue());
            Node<T> tempForNewList = NewList;
            list = list.GetNext();
            while (list != null)
            {
                Node<T> runner = new Node<T>(list.GetValue());
                tempForNewList.SetNext(runner);
                list = list.GetNext();
                tempForNewList = tempForNewList.GetNext();

            }
            return NewList;
        }
        //-----------------------Seif 14------------------------------//
        public static void RemoveDuplicates<T>(Node<T> list)
        {
            Node<T> current = list;

            while (current != null)
            {
                Node<T> runner = current;
                while (runner.GetNext() != null)
                {
                    if (current.GetValue().Equals(runner.GetNext().GetValue()))
                    {
                        runner.SetNext(runner.GetNext().GetNext());
                    }
                    else
                    {
                        runner = runner.GetNext();
                    }
                }
                current = current.GetNext();
            }
        }

        //-----------------------Seif 13------------------------------//
        static bool IfCircular<T>(Node<T> list)
        {

            Node<T> temp = list;
            while (temp != null)
            {
                temp = temp.GetNext();
                if (temp == list)
                {
                    return true;
                }


            }
            return false;
        }
        //-----------------------Seif 12------------------------------//
        static bool IfValueIsIn<T>(Node<T> list, T course)
        {

            Node<T> temp = list;
            while (temp != null)
            {
                if (temp.GetValue().Equals(course))
                {
                    return true;
                }
                temp = temp.GetNext();


            }
            return false;
        }
        //-----------------------Seif 11------------------------------//
        static T ReturnValByIndex<T>(Node<T> list, int index)
        {
            int counter = 0;
            Node<T> temp = list;
            while (counter < index)
            {

                temp = temp.GetNext();
                counter++;

            }
            return temp.GetValue();
        }
        //-----------------------Seif 10------------------------------//
        static T ReturnLastVal<T>(Node<T> list)
        {
            Node<T> temp = list;
            while (temp.HasNext())
            {

                temp = temp.GetNext();

            }
            return temp.GetValue();
        }
        //-----------------------Seif 9------------------------------//
        static T ReturnFirstVal<T>(Node<T> list)
        {
            return list.GetValue();
        }


        //-----------------------Seif 8------------------------------//
        static void DeleteAfter<T>(Node<T> prev)
        {
            prev.SetNext(prev.GetNext().GetNext());
        }
        //-----------------------Seif 7------------------------------//
        static Node<T> DeleteLast<T>(Node<T> head)
        {
            Node<T> temp = head;
            while (temp.GetNext().HasNext())
            {
                temp = temp.GetNext();
            }
            temp.SetNext(null);
            return head;

        }
        //-----------------------Seif 6------------------------------//
        static Node<T> DeleteFirst<T>(Node<T> head)
        {
            Node<T> temp = head;
            temp = temp.GetNext();
            return temp;

        }

        //-----------------------Seif 5------------------------------//
        static void AddAfter<T>(Node<T> prev, T value)
        {
            Node<T> nodeToMiddle = new Node<T>(value);
            nodeToMiddle.SetNext(prev.GetNext());
            prev.SetNext(nodeToMiddle);


        }

        //-----------------------Seif 4------------------------------//
        static Node<T> AddLast<T>(Node<T> head, T value)
        {
            Node<T> nodeToLast = new Node<T>(value);
            Node<T> temp = head;
            while (temp.HasNext())
            {

                temp = temp.GetNext();

            }
            temp.SetNext(nodeToLast);



            return head;

        }
        //-----------------------Seif 3------------------------------//
        static Node<T> AddFirst<T>(Node<T> head, T value)
        {
            Node<T> nodeToFirst = new Node<T>(value);

            nodeToFirst.SetNext(head);

            head = nodeToFirst;

            return head;

        }

        //-----------------------Seif 2------------------------------//
        static void PrintTheList<T>(Node<T> head)
        {
            Node<T> temp = head;

            while (temp != null)
            {
                Console.WriteLine(temp.GetValue());
                temp = temp.GetNext();

            }
        }

        //-----------------------Seif 1------------------------------//
        static int ListLength<T>(Node<T> head)
        {
            Node<T> temp = head;
            int counter = 0;
            while (temp != null)
            {
                counter++;
                temp = temp.GetNext();
            }
            return counter;
        }



    }
}

